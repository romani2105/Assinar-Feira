package entity;

public class Pagamento {

    private String numeroCartao;
    private boolean aprovado;

    public Pagamento(String numeroCartao) {
        this.numeroCartao = numeroCartao;
        this.aprovado = false;
    }

    public boolean validarPagamento() {

        if(numeroCartao.length() >= 8) {
            aprovado = true;
        }

        return aprovado;
    }

    public boolean isAprovado() {
        return aprovado;
    }
}