package entity;

import java.util.ArrayList;

public class Cesta {

    private ArrayList<Produto> produtos;

    public Cesta() {
        produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }
}