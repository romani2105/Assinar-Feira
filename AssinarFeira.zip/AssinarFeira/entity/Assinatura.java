package entity;

public class Assinatura {

    private Assinante assinante;
    private Plano plano;
    private Cesta cesta;
    private Endereco endereco;
    private Pagamento pagamento;

    public Assinatura(Assinante assinante,
                      Plano plano,
                      Cesta cesta,
                      Endereco endereco,
                      Pagamento pagamento) {

        this.assinante = assinante;
        this.plano = plano;
        this.cesta = cesta;
        this.endereco = endereco;
        this.pagamento = pagamento;
    }

    public void confirmarAssinatura() {
        System.out.println("Assinatura confirmada com sucesso!");
    }

    public Assinante getAssinante() {
        return assinante;
    }

    public Plano getPlano() {
        return plano;
    }
}
    