package entity;

public class Plano {

    private String nome;
    private double preco;
    private int limiteItens;

    public Plano(String nome, double preco, int limiteItens) {
        this.nome = nome;
        this.preco = preco;
        this.limiteItens = limiteItens;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getLimiteItens() {
        return limiteItens;
    }
}