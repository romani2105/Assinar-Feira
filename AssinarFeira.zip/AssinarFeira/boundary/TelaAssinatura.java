package boundary;

import controller.AssinaturaController;
import entity.*;

import java.util.Scanner;

public class TelaAssinatura {

    public void iniciar() {

        Scanner sc = new Scanner(System.in);

        AssinaturaController controller =
                new AssinaturaController();

        System.out.println("=== ASSINAR FEIRA ===");

        System.out.print("Nome: ");
        String nome = sc.nextLine();

        System.out.print("Celular: ");
        String celular = sc.nextLine();

        Assinante assinante =
                new Assinante(nome, celular);

        int codigoGerado = controller.gerarCodigo();

        System.out.println("Codigo enviado: "
                + codigoGerado);

        System.out.print("Digite o codigo: ");
        int codigo = sc.nextInt();
        sc.nextLine();

        if(!controller.validarCodigo(codigo)) {

            System.out.println("Codigo invalido.");
            return;
        }

        System.out.println("1 - Basico");
        System.out.println("2 - Premium");

        int opcao = sc.nextInt();
        sc.nextLine();

        Plano plano;

        if(opcao == 1) {
            plano = new Plano("Basico", 39.90, 5);
        } else {
            plano = new Plano("Premium", 59.90, 10);
        }

        Cesta cesta = new Cesta();

        String continuar = "s";

        while(continuar.equalsIgnoreCase("s")) {

            System.out.print("Produto: ");
            String produtoNome = sc.nextLine();

            System.out.print("Categoria: ");
            String categoria = sc.nextLine();

            Produto produto =
                    new Produto(produtoNome, categoria);

            cesta.adicionarProduto(produto);

            System.out.print("Adicionar outro? ");
            continuar = sc.nextLine();
        }

        System.out.print("Rua: ");
        String rua = sc.nextLine();

        System.out.print("Numero: ");
        int numero = sc.nextInt();
        sc.nextLine();

        System.out.print("CEP: ");
        String cep = sc.nextLine();

        Endereco endereco =
                new Endereco(rua, numero, cep);

        System.out.print("Numero do cartao: ");
        String cartao = sc.nextLine();

        Pagamento pagamento =
                new Pagamento(cartao);

        if(controller.validarPagamento(pagamento)) {

            Assinatura assinatura =
                    new Assinatura(
                            assinante,
                            plano,
                            cesta,
                            endereco,
                            pagamento
                    );

            assinatura.confirmarAssinatura();

            controller.salvarAssinatura(assinatura);

        } else {

            System.out.println("Pagamento recusado.");
        }
    }
}