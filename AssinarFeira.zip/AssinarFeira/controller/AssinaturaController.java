package controller;

import entity.*;
import persistence.AssinaturaRepository;

public class AssinaturaController {

    public int gerarCodigo() {
        return 1234;
    }

    public boolean validarCodigo(int codigo) {
        return codigo == 1234;
    }

    public boolean validarPagamento(Pagamento pagamento) {
        return pagamento.validarPagamento();
    }

    public void salvarAssinatura(Assinatura assinatura) {
        AssinaturaRepository.salvar(assinatura);
    }
}