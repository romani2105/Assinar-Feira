package persistence;

import entity.Assinatura;

import java.io.FileWriter;
import java.io.IOException;

public class AssinaturaRepository {

    public static void salvar(Assinatura assinatura) {

        try {

            FileWriter writer = new FileWriter("assinaturas.txt", true);

            writer.write("Assinante: "
                    + assinatura.getAssinante().getNome()
                    + "\n");

            writer.write("Plano: "
                    + assinatura.getPlano().getNome()
                    + "\n");

            writer.write("---------------------\n");

            writer.close();

        } catch(IOException e) {
            System.out.println("Erro ao salvar arquivo.");
        }
    }
}