//nomes: Murilo Bonventi Romani Pinto - RA 10729500 , Pedro Henrique Leite Silva - RA 10419352
public class Main {
    public static void main(String[] args) {

        Assinante assinante = new Assinante(1, "João", "119999999");
        Plano plano = new Plano(1, "Plano Básico", 50.0, 10);

        Produto p1 = new Produto(1, "Maçã", "Fruta");
        Produto p2 = new Produto(2, "Cenoura", "Legume");

        Cesta cesta = new Cesta();
        cesta.adicionarProduto(p1);
        cesta.adicionarProduto(p2);

        System.out.println("Assinante: " + assinante.getNome());
        System.out.println("Produtos na cesta:");
        cesta.listarProdutos();
    }
}