 public class Assinante {
    private int id;
    private String nome;
    private String celular;

    public Assinante(int id, String nome, String celular) {
        this.id = id;
        this.nome = nome;
        this.celular = celular;
    }

    public String getNome() {
        return nome;
    }
}