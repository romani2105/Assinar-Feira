 import java.util.ArrayList;
import java.util.List;

public class Cesta {
    private List<Produto> produtos;

    public Cesta() {
        produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public void listarProdutos() {
        for (Produto p : produtos) {
            System.out.println(p.getNome());
        }
    }
}