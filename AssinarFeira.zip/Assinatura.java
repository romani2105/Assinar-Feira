 public class Assinatura {
    private int id;
    private String status;
    private String dataInicio;

    public Assinatura(int id, String status, String dataInicio) {
        this.id = id;
        this.status = status;
        this.dataInicio = dataInicio;
    }
}