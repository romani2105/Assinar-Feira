public class Pagamento {
    private int id;
    private double valor;
    private String status;

    public Pagamento(int id, double valor, String status) {
        this.id = id;
        this.valor = valor;
        this.status = status;
    }
}