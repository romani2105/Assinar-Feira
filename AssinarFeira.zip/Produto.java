public class Produto {
    private int id;
    private String nome;
    private String tipo;

    public Produto(int id, String nome, String tipo) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }
}

