public class Plano {
    private int id;
    private String nome;
    private double preco;
    private int limite;

    public Plano(int id, String nome, double preco, int limite) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.limite = limite;
    }
}